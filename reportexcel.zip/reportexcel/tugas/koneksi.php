<?php
$host="localhost";
$username="root";
$password="";
$namadb ="db_siswa";
$conn = mysqli_connect($host, $username, $password, $namadb) or die("Koneksi gagal dibangun");
